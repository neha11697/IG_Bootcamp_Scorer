package com.project.dao.admin;

import com.project.models.Employee;

public interface Admin_Dao {
	void Register_Employee(Employee emp);
	
	
	
	
	
}
