package com.project.dao.admin;

import com.project.models.Employee;

public class Admin_Dao_Impl implements Admin_Dao{

	public void Register_Employee(Employee emp) {
		
		
	}
	

}
