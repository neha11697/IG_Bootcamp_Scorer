package com.project.models;


public class Admin {
	String adm_username;
	String adm_password;
	public Admin(String adm_username, String adm_password) {
		super();
		this.adm_username = adm_username;
		this.adm_password = adm_password;
	}
	public String getAdm_username() {
		return adm_username;
	}
	public void setAdm_username(String adm_username) {
		this.adm_username = adm_username;
	}
	public String getAdm_password() {
		return adm_password;
	}
	public void setAdm_password(String adm_password) {
		this.adm_password = adm_password;
	}
	public Admin() {
		super();
	}
	

}
